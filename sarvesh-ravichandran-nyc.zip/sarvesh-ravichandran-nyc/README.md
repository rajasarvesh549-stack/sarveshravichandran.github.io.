# Sarvesh Ravichandran — Portfolio (NYC edition)

A static website: one `index.html` plus its photos, video and PDFs. No build step,
no packages, no server code. Fonts are bundled in `fonts/`, so it doesn't rely on Google.

```
index.html     the whole site (styles, scripts, project pages, Fortune 1000 data)
css/fonts.css  local font setup
fonts/         font files + their open licences
img/ media/ research/   photos, demo video, NVIDIA slides, posture paper
.nojekyll      lets GitHub Pages serve the files as-is
```

## Option 1 — GitHub Pages (free, address with your GitHub name)
1. github.com → **+ → New repository** → name it `<your-username>.github.io` → Public → Create.
2. Click **uploading an existing file**, drag in everything *inside* this folder, **Commit changes**.
   (If `.nojekyll` doesn't come along, **Add file → Create new file**, name it `.nojekyll`, commit.)
3. **Settings → Pages →** Source: *Deploy from a branch*, Branch: `main`, folder `/ (root)` → **Save**.
4. In about a minute it's live at `https://<your-username>.github.io`.

## Option 2 — Netlify (free, fastest)
Go to **app.netlify.com/drop** and drag this whole folder onto the page. It's live
immediately; rename it under *Site configuration → Change site name*
(e.g. `sarvesh-ravichandran.netlify.app`).

## Option 3 — Vercel (free)
vercel.com → sign up with GitHub → **Add New → Project** → import the repository from
Option 1 → Framework *Other*, no build command → **Deploy**. Rename under *Settings → Domains*.

## Your own domain (optional)
Buy e.g. `sarveshravichandran.com` (Namecheap, Porkbun, Cloudflare). Then add it in your
host's domain settings (GitHub: *Settings → Pages → Custom domain*; Netlify/Vercel:
*Domains → Add*) and copy the DNS records they show into your registrar.

## Preview on your computer
```bash
cd sarvesh-ravichandran-nyc
python3 -m http.server 8000     # then open http://localhost:8000
```

## Editing
- All text is in `index.html`. Each project's full page is a `<template id="d-…">` block.
- Replace photos in `img/` keeping the same file names.
- The LinkedIn reaction/impression counts on the post cards are a snapshot from October 2026.
- The posture paper PDF lists co-authors and student IDs; check your teammates are fine with it being public.
